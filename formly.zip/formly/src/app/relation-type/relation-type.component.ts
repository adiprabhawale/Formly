import { Component, OnInit } from '@angular/core';
import { FieldType } from '@ngx-formly/core';
import { FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { debounceTime, switchMap, startWith, map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

const BASE_URL = 'http://localhost:1337/api';

@Component({
  selector: 'formly-relation-type',
  template: `
    <div *ngIf="to['relation'] === 'many'">
      <mat-chip-list [formControl]="relationControl">
        <mat-chip *ngFor="let option of relationControlValues" [removable]="true" (removed)="remove(option)">
          {{ getNameById(option) }}
          <mat-icon matChipRemove>cancel</mat-icon>
        </mat-chip>
      </mat-chip-list>
    </div>

    <mat-form-field appearance="outline" [style.width]="'100%'">
      <mat-label>{{ to['title']}}</mat-label>
      <input matInput [matAutocomplete]="auto" [formControl]="searchControl">
      <mat-autocomplete #auto="matAutocomplete" (optionSelected)="onOptionSelected($event)">
        <mat-option *ngFor="let option of filteredOptionsList | async" [value]="option.id">
          {{ option.name }}
        </mat-option>
      </mat-autocomplete>
    </mat-form-field>
  `
})
export class RelationTypeComponent extends FieldType implements OnInit {
  relationControl = new FormControl<string[] | string | null>([]);
  searchControl = new FormControl();
  filteredOptionsList: Observable<{ id: number, name: string }[]> = of([]);
  optionsList: { id: number, name: string }[] = [];

  get relationControlValues(): string[] {
    return this.relationControl.value as string[] || [];
  }

  constructor(private http: HttpClient) {
    super();
  }

  ngOnInit() {
    // Set the value of Formly field's formControl to be in sync with relationControl
    this.relationControl.valueChanges.subscribe(val => {
      this.field.formControl!.setValue(val);
    });

    this.filteredOptionsList = this.searchControl.valueChanges.pipe(
      startWith(''),
      debounceTime(300),
      switchMap(value => this.fetchOptions(value))
    );
  }


  onOptionSelected(event: any) {
    const selectedId = event.option.value;
    if (this.to['relation'] === 'many') {
      this.relationControl.setValue([...this.relationControlValues, selectedId]);
    } else {
      this.relationControl.setValue(selectedId);
    }
    this.searchControl.setValue(''); // clear the search input
  }

  getNameById(id: string): string {
    const found = this.optionsList.find(option => {
      console.log('Checking option ID:', option.id.toString());
      return option.id.toString() === id;
  });
    return found ? found.name : '';
  }

  remove(option: any): void {
    const index = this.relationControlValues.indexOf(option);
    if (index >= 0) {
      const newValue = [...this.relationControlValues];
      newValue.splice(index, 1);
      this.relationControl.setValue(newValue);
    }
  }

  private fetchOptions(filterValue: string): Observable<{ id: number, name: string }[]> {
    if (!filterValue || typeof filterValue !== 'string' || filterValue.length === 0) {
      return of([]);
    }
    const mainField = this.to['mainField'];
    const url = `${BASE_URL}/${this.to['api']}?filters[${mainField}][$contains]=${filterValue}`;

    return this.http.get<any>(url).pipe(
      map(response => {
        const filteredData = response.data.filter(
          (item: any) => !this.relationControlValues.includes(item.id)
        );
        this.optionsList = filteredData.map((item: { id: any; attributes: { [x: string]: any; name: any; }; }) => ({
          id: item.id,
          name: item.attributes[this.to['field']] || item.attributes.name
        }));
        return this.optionsList;
      })
    );
  }
}