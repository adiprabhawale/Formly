import { Component } from '@angular/core';
import { FieldArrayType } from '@ngx-formly/core';

@Component({
  selector: 'formly-repeat-section',
  templateUrl: './repeat-type.component.html'
})
export class RepeatTypeComponent extends FieldArrayType { }
