export function generateFormlySchema(initSchema: { data: { contentTypes: any[]; components: any; }; }, configSchema: { data: { contentType: { uid: any; layouts: { edit: any[]; }; metadatas: { [x: string]: { edit: any; }; }; }; components: any; }; }) {
    const contentTypeUID = configSchema.data.contentType.uid;
    const contentType = initSchema.data.contentTypes.find(ct => ct.uid === contentTypeUID);

    if (!contentType) {
        throw new Error('Content type not found in init schema.');
    }

    const layout = configSchema.data.contentType.layouts.edit;
    return layout.map((row: any[]) => ({
        fieldGroup: row
            .map((fieldLayout: any) => {
                const attr = fieldLayout.name;
                const attribute = contentType.attributes[attr];
                const configMeta = configSchema.data.contentType.metadatas[attr]?.edit;

                if (configMeta && configMeta.visible) {
                    return generateFormlySchemaField(attr, attribute, configMeta, initSchema, configSchema, fieldLayout.size);
                }
                return null;
            })
            .filter(Boolean)
    }));
}

function generateFormlySchemaField(attr: string, attribute: any, configMeta: any, initSchema: any, configSchema: any, fieldSize: number) {
    const commonTemplateOptions = {
        label: configMeta.label,
        placeholder: configMeta.placeholder,
        description: configMeta.description,
        required: attribute['required'],
        ...generateErrorMessages(attribute)
    };

    if (attribute.type === 'relation') {
        const target = attribute.target;
        const targetContentType = initSchema.data.contentTypes.find((ct: { uid: any; }) => ct.uid === target);

        if (!targetContentType) {
            throw new Error('Target content type not found in init schema.');
        }

        return {
            key: attr,
            type: 'relation',
            templateOptions: {
                api: targetContentType.info.pluralName,
                relation: attribute.relation === 'manyToMany' ? 'many' : 'one',
                mainField: configMeta.mainField
            }
        };
    } else {
        return {
            key: attr,
            type: getFormlyFieldType(attribute),
            className: getBootstrapClass(fieldSize),
            defaultValue: attribute.default,
            templateOptions: {
                ...commonTemplateOptions,
                options: attribute.enum ? attribute.enum.map((e: any) => ({ label: e, value: e })) : [],
                minLength: attribute.minLength,
                maxLength: attribute.maxLength,
                pattern: attribute.regex
            },
            fieldArray: attribute.type === 'component' ? {
                fieldGroup: generateComponentFields(initSchema.data.components, attribute, configSchema.data.components)
            } : null
        };
    }
}

// ... [Rest of the code remains unchanged] ...


function generateErrorMessages(attribute: any) {
    let errorMessages: { [key: string]: string } = {};

    if (attribute['required']) {
        errorMessages['required'] = `${attribute.label || 'This field'} is required.`;
    }
    if (attribute.minLength) {
        errorMessages['minlength'] = `Minimum length should be ${attribute.minLength} characters.`;
    }
    if (attribute.maxLength) {
        errorMessages['maxlength'] = `Maximum length should be ${attribute.maxLength} characters.`;
    }
    if (attribute.regex) {
        errorMessages['pattern'] = `${attribute.label || 'This field'} format is invalid.`;
    }

    return { errorMessages };
}

function getBootstrapClass(size: number): string {
    const classes: { [key: number]: string } = {
        4: "col-md-4",
        6: "col-md-6",
        8: "col-md-8",
        12: "col-md-12"
    };
    return classes[size] || "";
}

function getFormlyFieldType(attribute: { type: string }): string {
    const types: { [key: string]: string } = {
        'string': 'input',
        'integer': 'input',
        'datetime': 'datepicker',
        'time': 'input',
        'enumeration': 'select',
        'relation': 'select',
        'component': 'repeat'
    };
    return types[attribute.type] || 'input';
}

function generateComponentFields(components: any[], attribute: { component: any; }, configComponents: { [x: string]: any; }): any[] {
    const component = components.find(c => c.uid === attribute.component);
    const componentConfig = configComponents[component.uid];

    return Object.keys(component.attributes)
        .map(compAttr => {
            const configMeta = componentConfig.metadatas[compAttr]?.edit;

            if (configMeta && configMeta.visible) {
                const fieldAttr = component.attributes[compAttr];
                const commonTemplateOptions = {
                    label: configMeta.label,
                    placeholder: configMeta.placeholder,
                    description: configMeta.description,
                    required: fieldAttr['required'],
                    ...generateErrorMessages(fieldAttr)
                };

                return {
                    key: compAttr,
                    type: getFormlyFieldType(fieldAttr),
                    templateOptions: {
                        ...commonTemplateOptions,
                        options: fieldAttr.enum ? fieldAttr.enum.map((e: any) => ({ label: e, value: e })) : []
                    }
                };
            }
            return null;
        })
        .filter(Boolean);
}
