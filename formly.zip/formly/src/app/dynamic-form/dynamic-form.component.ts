import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup } from '@angular/forms';
import { FormlyFieldConfig } from '@ngx-formly/core';

import { generateFormlySchema } from './converter';
import * as initSchema from './init.json';
import * as configSchema from './config.json';


@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html'
})
export class DynamicFormComponent implements OnInit {
  @Input() schemaUrl!: string; // Using '!' to satisfy TypeScript's strict checks.

  form = new FormGroup({});
  model = {};
  fields!: FormlyFieldConfig[]; // Using '!' to satisfy TypeScript's strict checks.

  constructor(private http: HttpClient) {}

  ngOnInit() {
    // this.http.get(this.schemaUrl).toPromise().then(data => {
    //   this.fields = data as FormlyFieldConfig[];
    // });

    this.fields = generateFormlySchema(initSchema, configSchema) as FormlyFieldConfig[];
    console.log(JSON.stringify(generateFormlySchema(initSchema, configSchema)))

  }

  // Add this method to address the 'onSubmit' error.
  onSubmit() {
    console.log(this.model); // For now, we'll just log the model. You can expand on this.
  }
}
